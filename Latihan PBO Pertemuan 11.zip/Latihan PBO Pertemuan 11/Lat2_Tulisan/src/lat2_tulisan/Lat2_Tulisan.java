/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lat2_tulisan;

import java.awt.*;
/**
 *
 * @author RECKY
 */
public class Lat2_Tulisan extends Panel{
    Font f;
    String text = "HALO KHARISMA";
    Lat2_Tulisan(){
        setBackground(Color.GRAY);
    }
    
    public void paint(Graphics g)
    {
        f = new Font("Helvetica", Font.BOLD, 48);
        
        //kotak hijau
        g.setColor(Color.GREEN);
        g.fillRect(8, 8, 470, 105);
        
        //warna hitam pinggiran
        g.setColor(Color.BLACK);
        g.drawRect(8, 8, 470, 105);
        g.setColor(Color.pink);
        g.fillOval(10, 10, 467, 100);
        
        //diberi pinggiran warna merah tebal (3x)
        g.setColor(Color.red);
        g.drawOval(10, 10, 467, 100);
        g.drawOval(9, 9, 467, 102);
        g.drawOval(8, 8, 467, 104);
        
        //tulisan warna hitam dengan font helvetica
        g.setColor(Color.black);
        g.setFont(f);
        g.drawString(text, 40, 75);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame f = new Frame("Testing Graphics Panel 2");
        Lat2_Tulisan gp = new Lat2_Tulisan();
        f.add(gp);
        f.setSize(600, 600);
        f.setVisible(true);
    }
    
}
